#!/usr/bin/env bash
set -euo pipefail

# This helper can be used to filter known acceptable warnings on macOS toolchains
# if we need to keep WERROR while tolerating specific deprecations.
# Currently not used; kept here for quick activation in CI if required.

exit 0

